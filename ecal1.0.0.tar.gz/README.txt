Eternal Calendar

This program generates a calendar for any given date from Before Christ (BC) to
Anno Domino (AD), hence the name eternal calendar.

When the executible is run, it first displays the calendar of the current month
highlighting the current date. Arrow keys can be used to move around to check
the calendar of different months. Significance of each arrow key operation has
been shown in detail. A new date also could be entered to get the calendar of
the specified month.
