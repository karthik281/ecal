#include <ncurses.h>
#include <stdlib.h>
#include <math.h>

#define ENTER_KEY 10

static int first_sunday [7][12] = {
					7,4,4,1,6,3,1,5,2,7,4,2,
					6,3,3,7,5,2,7,4,1,6,3,1,
					5,2,2,6,4,1,6,3,7,5,2,7,
					4,1,1,5,3,7,5,2,6,4,1,6,
					3,7,7,4,2,6,4,1,5,3,7,5,
					2,6,6,3,1,5,3,7,4,2,6,4,
					1,5,5,2,7,4,2,6,3,1,5,3
				  };

static char *days[7] = {
				"SUN", 
				"MON",
				"TUE",
				"WED",
				"THU",
				"FRI",
				"SAT"
	               };

static char *months[12] = {
				"JANUARY",
				"FEBRUARY",
				"MARCH",
				"APRIL",
				"MAY",
				"JUNE",
				"JULY",
				"AUGUST",
				"SEPTEMBER",
				"OCTOBER",
				"NOVEMBER",
				"DECEMBER",
	 		  };

int mnts[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

int dd = 0, mm = 0;
long int yy = 0;

//1/1/2001 is a Monday
int i, yr;

//2001 A.D. is set as the base
int year()
{
	return yy < yr? -1 : 1;
}

bool gregorian()
{
	if( yy <= 1751 || ( yy == 1752 && mm <= 9 ) )
	{
		yr = 1752;
		i = 3;
		return TRUE;
	}
	else
	{
		i = 0;
		yr = 2001;
		return FALSE;
	}
}

//Checks for a leap year
int isleap(long int y)
{
	if( yy > 1700 )
		return ((y % 4 == 0) && (y % 100 != 0)) || (y % 400 == 0);
	return y % 4 == 0;
}     

//Returns the first day number of the month as in Sunday = 0 and so on...
//Returns the row no. 
int rowno()
{
	gregorian();
	while( yr != yy )
		if ( year() > 0 )
		{
			yr += year();
			i = ( i + 1 + isleap(yr)) % 7; 
		}
		else
		{
			i = i - 1 - isleap(yr);
			i = i < 0 ? i + 7 : i;
			yr += year();
		}
	return i;
}
	
int getfirstday(int row)
{
     
     int fs, day, d = 1;
     
     fs = first_sunday[row][mm - 1];
     day = d - 1 * ( isleap( yy ) && mm < 3 ) - fs;
     return day = day < 0 ? day + 7: day;
}

//Prints the Calender of the mnth specified
void calender(int day)
{
  int row_count, col_count, count;

  if(isleap( yy ))
    mnts[1] = 29;
  attrset( A_UNDERLINE );
  mvprintw( 5, 10, "%s", months[ mm - 1 ] );
  mvprintw( 5, 33, "%ld %s", labs(yy) , yy >= 0 ? "A.D." : "B.C.");
  attroff( A_UNDERLINE );
  //Prints the heading for the days
  for( count = 0; count < 7; count++ )
    mvprintw( 7, 6 * ( count + 1 ), "%s",days[count]);     
  //Prints the days
  for( row_count = 0, col_count = day, count = 1; count <= mnts[ mm - 1 ]; col_count++, count++)
  {
    if(col_count == 7)
      row_count++, col_count = 0;
    if( !isleap(yy) && count == 29 && mm == 2 )
      return ;
    if( mm == 9 && yy == 1752 && count == 3 )
      while( count < 14 )
        count++;			
    if( count == dd )
    {
      attron(COLOR_PAIR(1));
      mvprintw(10 + 2 * row_count, 6 * (col_count + 1) + 1 + 1 * ( count < 10 ), "%d", count);
      attroff(COLOR_PAIR(1));
    }
    else
      mvprintw(10 + 2 * row_count, 6 * (col_count + 1) + 1 + 1 * ( count < 10 ), "%d", count);
  }
}

//Checks the vadilidty of the date entered 
bool valid()
{
	bool flag = TRUE;
	
	if( dd <= 13 && dd >= 4 && mm == 9 && yy == 1752 )
		printw("\n Gregorian Reformation\n"), flag = FALSE;
	if ( dd < 1 )
		printw("\n Day cannot be less than 1\n"), flag = FALSE;
	else if( dd == 29 && mm == 2 && !isleap(yy)) 
		printw("\n Year %d is not Leap for FEB to have 29 days\n", yy), flag = FALSE;
	else if( mm < 1 || mm > 12 )
		printw("\n Months can b only b/w 1 and 12 (inclusive)\n"), flag = FALSE;
	else if( dd > mnts[mm - 1] )
		printw("\n Month %d has only %d days.\n", mm, mnts[mm - 1]),flag = FALSE;
	return flag;
}

// Sets the parameters for printing the calender         
void print()
{
	int row, fs_day;
	
	row = rowno();
	fs_day = getfirstday(row);
	calender(fs_day);
	refresh();
}

//Prints the menu
void print_details()
{
	mvprintw(22, 2, "USE LEFT/RIGHT ARROW KEYS TO GET PREVIOUS/NEXT YEARS"); 
	mvprintw(24, 2, "USE DOWN/UP ARROW KEYS TO GET PREVIOUS/NEXT MONTHS"); 
	mvprintw(26, 2, "PRESS ENTER TO ENTER A NEW DATE");
	mvprintw(28, 2, "PRESS ^C TO EXIT");
	refresh();
}

//Returns TRUE if ch is a digit
int digit( int ch )
{
	return ch >= 0 && ch <= 9;
}

//Parse the date
void parse( char * date )
{
	int i = 0, val = 10, ch;
		
	while( ch = date[ i++ ] - '0', digit( ch ) )
		yy = yy * val + ch;
	while( ch = date[ i++ ] - '0', digit( ch ) )
		mm = mm * val + ch;
	while( ch = date[ i++ ] - '0', digit( ch ) )
		dd = dd * val + ch;
}

//gets the date from the user
void askdate()
{
	char date[ 20 ];
	int ch, indx = 0;
	
	curs_set(TRUE);
	do 
	{
		//printw("\n ENTER THE DATE IN year/mm/dd FORM(-ve YEAR INDICATES B.C.): ");
		//scanw("%d%c%d%c%d",&yy,&ch,&mm,&ch,&dd);
		printw("\n ENTER THE DATE IN dd/mm/yyyy FORM(-ve YEAR INDICATES B.C.): ");
		scanw("%d%c%d%c%d",&dd,&ch,&mm,&ch,&yy);
	} while( !valid() );
	system("clear");
	mvprintw(4 ,5 ,"THE ENTERED VALID DATE IS %d/%d/%d", dd,mm,yy);
	curs_set(FALSE);
	refresh();
}

//Prints the menu and sets the parameters accordingly
void menu(int ch)
{
	switch( ch )
	{
		case KEY_LEFT: yy--;
			       break;
			       
		case KEY_RIGHT: yy++;
				break;
				
		case KEY_UP: yy += ( mm == 12 ), mm++;
			     if( mm > 12 )
				     mm = 1;
			     break;

		case KEY_DOWN: yy -= ( mm == 1 ), mm--;
			       if( mm < 1 )
				       mm = 12;
			       break;

		case ENTER_KEY: askdate();
			 break;

		default: mvprintw(2, 2, "WRONG OPTION");
	}
	refresh();
}

//Prints the current months's calender
void thismonth()
{
	system("clear ; date +%F > datefile");

	int ch, i = 0;
	char currdate[ 11 ];
	FILE *fp = fopen( "datefile" , "r" );
	while( ( ch = fgetc( fp ) ) != EOF )
		currdate[ i++ ] = ch;
	currdate[ 10 ] = '\0';
	parse( currdate );
	fclose( fp );
	system("rm datefile");
}

int main()
{
	int ch;     
	int row, day, i;
        long int y;

	initscr();
	start_color();
	keypad(stdscr, TRUE);
	init_pair(1,COLOR_WHITE,COLOR_BLUE);
	init_pair(2,COLOR_WHITE,COLOR_RED);
	clear();

	thismonth();
	while(1)
	{
		print();
		print_details();
		refresh();
		ch = getch();
		clear();
		menu( ch );
	}

	endwin();
	return 0 ;
}
